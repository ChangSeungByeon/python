import random
from os import listdir, makedirs


soju_list = ['참이슬', '처음처럼', '시원한 청풍', 'O2린', '하이트', '잎새주', '참소주', '화이트',\
             '좋은데이','C1', '한라산', '처음처럼 순하리', '순한참', '부라더 소다']


j = 0
joke = False

file_list = listdir('C:\\Users')
# print(file_list)

try:

    for i in file_list:
        if '.' in i or i == 'Default' or i == 'Default User' or i == 'Public':

            None


        else:
            file_list_desk = listdir('C:\\Users\\'+i)

            if 'Desktop' in file_list_desk:
                result_route = 'C:\\Users\\'+ i + '\\Desktop'
                joke = True
                break

            # print(i+' 케이스:')
            # print('Desktop이 있나?'+str('Desktop' in file_list_desk))
            # print(file_list_desk)
            # print('\n')

except:
    joke = False


while True :

    choose = input('소주를 랜덤으로 뽑으려면 엔터를 치세요\n(종료하려면 아무런 글씨나 입력 후 엔터)\n')

    if choose == '':

        soju_random = soju_list[random.randrange(0, len(soju_list))]
        print('****** ' + soju_random + ' ******')
        print('\n')


        try:
            j += 1
            makedirs(result_route + '\\' + '영석이 ㄲㅊ ' + str(random.randrange(0, 100)) + 'nm')
        except:

            None

    else:

        break






# print(soju_random)


