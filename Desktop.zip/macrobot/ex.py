print(print(3))

a = [1, 2,34,5,6,7]

print(a[0:-3])

print(5 & '7')