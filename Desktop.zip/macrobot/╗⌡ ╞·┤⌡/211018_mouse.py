import pyautogui
import time

gap_check_sec = 60

screenWidth, screenHeight = pyautogui.size()
print('{0}, {1}'.format(screenWidth, screenHeight))

# pyautogui.moveTo(50, 50)
#
# pyautogui.click(x=200, y=200)
# pyautogui.moveTo(177, 608)
# pyautogui.scroll(-100)

point_past = pyautogui.position()

while True:

    if point_past == pyautogui.position():

        pyautogui.moveTo(500, 500)
        pyautogui.moveTo(177, 608)
        pyautogui.moveTo(500, 500)
        point_past = pyautogui.position()
        print('wake up!')

        time.sleep(gap_check_sec)



    else:
        point_past = pyautogui.position()
        print('working')

        time.sleep(gap_check_sec)
