import datetime
import time

now = time.localtime()

print(now.tm_hour, now.tm_min, now.tm_sec)

sec_now = now.tm_hour*3600 + now.tm_min*60 + now.tm_sec

print(sec_now)

sec_09_55_00 = 9*3600 + 55*60
sec_09_59_55 = 9*3600 + 59*60 + 55

print(sec_09_59_55)
print(sec_09_55_00)

#
# 출처: https://technote.kr/264 [TechNote.kr]
#
# now = datetime.datetime.now()
# print(now)
# print(type(now))
# print(now.tm_hour, now.tm_min, now.tm_sec)