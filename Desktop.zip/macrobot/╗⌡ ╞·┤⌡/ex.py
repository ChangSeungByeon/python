participant = ["leo", "kiki", "eden"]
completion = ["leo", "kiki"]

for i in participant:
    # print(i)
    if not(i in completion):
        answer = i
        break

