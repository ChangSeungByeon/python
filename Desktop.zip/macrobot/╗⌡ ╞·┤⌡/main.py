from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import datetime
import pyautogui

def now():
    nowtime = str(datetime.datetime.now().time())
    return (float(nowtime[0:2])*3600+float(nowtime[3:5])*60+float(nowtime[6:]))

def time2sec(A):
    return float((int(A[0:2])*3600+int(A[2:4])*60+int(A[4:])))

def time_remain(A,B):
    return (B-A)


time_login = time2sec('000500')

time_pagein = time2sec('000100')

time_pagerefresh = time2sec('000004')

# real

# time_end = time2sec('101000')
# time_ten = time2sec('100000')

first_level = [] # 0 1 2 3 중에서
second_level = [] # 0 1 중에서

# test

time_end = time2sec('193000')
time_ten = time2sec('065900')
#

mobile_emulation = { "deviceName": "Galaxy S5" }

chrome_options = webdriver.ChromeOptions()

chrome_options.add_experimental_option("mobileEmulation", mobile_emulation)

driver = webdriver.Chrome(options=chrome_options,executable_path="C:/Users/BCS/Downloads/chromedriver.exe")

driver.get("https://login.11st.co.kr/auth/login.tmall")


wait = WebDriverWait(driver, 2, poll_frequency=0.01)




# while(time_ten - now() > 0):
#     if time_ten - now() > 0:
#         time.sleep(time_ten - now())
#     else:
#         break

graphic = "http://m.11st.co.kr/MW/Product/productBasicInfo.tmall?prdNo=3167879989&mallType=mobile"
game = 'http://m.11st.co.kr/MW/Product/productBasicInfo.tmall?prdNo=3326702930&trTypeCd=54&trCtgrNo=2051889'
cloth = 'http://m.11st.co.kr/MW/Product/productBasicInfo.tmall?prdNo=2746145240'
#to do 버튼 클릭할 수 있을때까지 새로고침 & 시간 연동

x = game

start_1 = now()

# driver.refresh()
driver.get(x)
wait.until(EC.presence_of_element_located((By.CLASS_NAME, "buy"))).click()


selec_opt_elem = wait.until(EC.presence_of_element_located((By.CLASS_NAME, "select_opt")))
time.sleep(0.23)
selec_opt_elem.click()
opt_list_0 = driver.find_element_by_id('optlst_0').find_elements_by_tag_name('a')

item_option_0 = opt_list_0[1].get_attribute('data-optvalue')
print("ul#optlst_0 a[data-optvalue='" + item_option_0 + "']")
wait.until(
    EC.element_to_be_clickable((By.CSS_SELECTOR, "ul#optlst_0 a[data-optvalue='" + item_option_0 + "']"))).click()
try:
    WebDriverWait(driver, 1, poll_frequency=0.01).until(
        EC.presence_of_element_located((By.XPATH, "//button[@data-log-actionid-label='buy_now']"))).click()
except:
    print('except in')
    opt_list_1 = driver.find_element_by_id('optlst_1').find_elements_by_tag_name('a')
    item_option_1 = opt_list_1[1].get_attribute('data-optvalue')
    print(item_option_1)

    wait.until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "ul#optlst_1 a[data-optvalue='" + item_option_1 + "']"))).click()

print(now() - start_1)
print(1)

while(True):
    try:
        print(now())
        driver.get('http://m.11st.co.kr/MW/Product/productBasicInfo.tmall?prdNo=2746145240')
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, "buy"))).click()

        selec_opt_elem = wait.until(EC.presence_of_element_located((By.CLASS_NAME, "select_opt")))

        time.sleep(0.23)
        selec_opt_elem.click()

        wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "ul#optlst_0 a[data-optvalue='1:2']"))).click()

        try:
            driver.find_element_by_xpath("//button[@data-log-actionid-label='buy_now']").click()
        except:
            WebDriverWait(driver, 1, poll_frequency=0.01).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "ul#optlst_0 a[data-optvalue='1:1']"))).click()


        wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@id='doPaySubmit']"))).click()

        paypw = wait.until(EC.element_to_be_clickable((By.ID, 'skpay-ui-frame-wapper')))
        driver.switch_to.frame(driver.find_element_by_xpath("//iframe[@src='https://11pay.11st.co.kr/pages/skpay/authorize?type=PIN_NUM_AUTH&poc=web&step=payment&pinOpened=true']"))

        wait.until(EC.element_to_be_clickable((By.ID, 'keypad11pay-keypad-0'))).click()
        driver.find_element_by_id('keypad11pay-keypad-10').click()
        driver.find_element_by_id('keypad11pay-keypad-0').click()
        driver.find_element_by_id('keypad11pay-keypad-10').click()
        driver.find_element_by_id('keypad11pay-keypad-0').click()
        driver.find_element_by_id('keypad11pay-keypad-10').click()

        time.sleep(200)
        break

    except:
        print(1)

